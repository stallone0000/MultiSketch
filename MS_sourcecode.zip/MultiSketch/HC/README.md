# MultiSketch Heavy Change Detection

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./main ./XX.data (Memory)
```

`XX.data` is a dataset, Memory is the memory usage (unit is MB).

## Output format

Our program will print the Precision, Recall, F1-score, ARE of MultiSketch and other seven sketches.
